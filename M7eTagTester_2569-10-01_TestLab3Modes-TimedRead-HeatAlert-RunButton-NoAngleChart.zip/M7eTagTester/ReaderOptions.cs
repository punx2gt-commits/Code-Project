namespace M7eTagTester;

// ค่า default ของ reader — แก้ได้ใน appsettings.json (ไม่ต้อง compile ใหม่)
public class ReaderOptions
{
    public string Uri { get; set; } = "sim";          // "sim" หรือ "tmr:///COM7"
    public string Region { get; set; } = "TH";        // โซนความถี่ไทย (M7e รองรับ TH โดยตรง)
    public int ReadPowerDbm { get; set; } = 20;        // กำลังส่ง dBm
    public int Antenna { get; set; } = 1;              // พอร์ตเสาอากาศ
    public int BaudRate { get; set; } = 115200;        // baud default ของ M7e
    public int ExpectedTags { get; set; } = 100;       // จำนวน tag ที่คาดไว้
    public int WeakRssi { get; set; } = -65;           // เกณฑ์สัญญาณอ่อน

    // ===== ตั้งค่าขั้นสูง (เหมือน URA) =====
    public string ReadMode { get; set; } = "cont";     // cont | once | n
    public int ReadN { get; set; } = 10;               // จำนวนแท็กสำหรับโหมด N
    public int RfOn { get; set; } = 1000;              // RF On (ms) — duty cycle
    public int RfOff { get; set; } = 0;                // RF Off (ms)
    public string SearchMode { get; set; } = "dynamic";// dynamic | equal
    public bool FilterEnable { get; set; } = false;    // เปิดตัวกรอง EPC
    public string FilterEpc { get; set; } = "";        // EPC mask สำหรับกรอง
    public bool GpoAuto { get; set; } = false;         // สั่ง GPO อัตโนมัติตอน PASS/FAIL
    public string RfMode { get; set; } = "";           // RF Mode (DEKA 5 โหมด) ; "" = ไม่ตั้ง
    public string PowerMode { get; set; } = "FULL";    // FULL | MINSAVE | SLEEP
}
