using M7eTagTester;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<ReaderOptions>(builder.Configuration.GetSection("Reader"));
builder.Services.AddSignalR();
builder.Services.AddSingleton<ReaderService>();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();
app.MapHub<TagHub>("/tagHub");

var reader = app.Services.GetRequiredService<ReaderService>();

// ค่า default ปัจจุบัน (หน้าเว็บดึงไป prefill)
app.MapGet("/api/config", () => Results.Json(reader.Defaults));

// รายชื่อ COM port ในเครื่อง (ปุ่มรีเฟรชในหน้าเว็บเรียกอันนี้)
#pragma warning disable CA1416 // GetPorts ใช้ WMI เฉพาะ Windows — แอปนี้รันบน Windows อยู่แล้ว
app.MapGet("/api/ports", () => Results.Json(reader.GetPorts()));
app.MapGet("/api/driver-check", () => Results.Json(reader.CheckDriver()));
#pragma warning restore CA1416

// ตรวจ reader: ดึงรุ่น / ช่วง power / พอร์ต (universal เหมือน URA)
app.MapPost("/api/detect", (DetectRequest req) =>
{
    try { return Results.Json(reader.Detect(req.Port, req.Baud)); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message }); }
});

// ตรวจเสาที่ต่ออยู่ (ใช้เด้ง popup ตอนเริ่มอ่าน ถ้าเสาไม่ตรง/ไม่เจอ)
app.MapPost("/api/antenna-check", (AntennaCheckRequest req) =>
{
    try { var a = reader.CheckAntennas(req.Port, req.Baud, true); return Results.Json(new { ok = true, ports = a.Ports, connected = a.Connected }); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message }); }
});

// Power Sweep (P50): ไล่ power หา turn-on ของแท็ก
app.MapPost("/api/sweep", (SweepRequest req) =>
{
    if (reader.Running) return Results.BadRequest(new { ok = false, error = "กำลังอ่านต่อเนื่องอยู่ — กดหยุดก่อน แล้วค่อย Sweep" });
    try { return Results.Json(reader.SweepRun(req.Port, req.Baud, req.Region, req.Antenna,
                              req.Start ?? 5, req.End ?? 27, req.Step ?? 1, req.N ?? 20)); }
    catch (ReaderFaultException ex) { return Results.BadRequest(new { ok = false, error = ex.Message, fault = ex.Kind }); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message, fault = ReaderFaultException.Classify(ex.Message) }); }
});

// ทดสอบ QC: อ่าน N ครั้ง คืน hits/RSSI (เว็บคำนวณ Wilson + PASS/FAIL เอง)
app.MapPost("/api/qc-run", (QcRunRequest req) =>
{
    try { return Results.Json(reader.QcRun(req.Port, req.Baud, req.Region, req.Power, req.Antenna, req.N ?? 100, req.Duration ?? 0)); }
    catch (ReaderFaultException ex) { return Results.BadRequest(new { ok = false, error = ex.Message, fault = ex.Kind }); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message, fault = ReaderFaultException.Classify(ex.Message) }); }
});

// บันทึกค่าจากหน้าเว็บลง appsettings.json (ค่าเริ่มต้นถาวร)
app.MapPost("/api/config", (ReaderOptions o) =>
{
    try { reader.SaveDefaults(o); return Results.Ok(new { ok = true }); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message }); }
});

// ตั้งชื่อให้ tag (ผูกกับ EPC) — จำถาวร
app.MapPost("/api/tagname", (TagNameRequest req) =>
{
    try { reader.SetName(req.Epc, req.Name ?? ""); return Results.Ok(new { ok = true }); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message }); }
});

// เริ่มอ่าน (รับค่าขั้นสูงเพิ่ม)
app.MapPost("/api/start", (StartRequest req) =>
{
    try
    {
        var adv = new ReadSettings(
            req.RfOn ?? 1000, req.RfOff ?? 0,
            req.ReadMode ?? "cont", req.ReadN ?? 10,
            req.FilterEnable ?? false, req.FilterEpc,
            req.SearchMode ?? "dynamic", req.GpoAuto ?? false,
            req.RfMode, req.PowerMode ?? "FULL",
            req.PowerScope ?? "global", req.PortPowers,
            req.WritePower, req.AntDetect ?? true, req.AntMux ?? false, req.AntennaList);

        reader.Start(req.Port, req.Region, req.Power, req.Antenna, req.Baud, adv);
        return Results.Ok(new { ok = true });
    }
    catch (Exception ex)
    {
        try { reader.Stop(); } catch { }   // เริ่มไม่สำเร็จ → ปิดพอร์ตที่ค้างครึ่ง ๆ ให้เชื่อมต่อใหม่ได้
        return Results.BadRequest(new { ok = false, error = ex.Message, fault = ReaderFaultException.Classify(ex.Message) });
    }
});

app.MapPost("/api/stop", () => { reader.Stop(); return Results.Ok(new { ok = true }); });
app.MapPost("/api/reset", () => { reader.Reset(); return Results.Ok(new { ok = true }); });
app.MapGet("/api/tags", () => Results.Json(reader.Snapshot()));

// สถานะ reader — อุณหภูมิ + กำลังอ่านอยู่ไหม (หน้าเว็บ poll ทุก 3 วิ)
app.MapGet("/api/status", () => Results.Json(new { temperature = reader.Temperature, reading = reader.Running, fault = reader.FaultInfo }));

// สั่ง GPO (รีเลย์/ไฟแสดงผล)
app.MapPost("/api/gpo", (GpoRequest q) =>
{
    try { reader.SetGpo(q.Pin, q.State); return Results.Ok(new { ok = true }); }
    catch (Exception ex) { return Results.BadRequest(new { ok = false, error = ex.Message }); }
});

app.MapGet("/api/export", () =>
{
    // รูปแบบเดียวกับ Universal Reader Assistant (URA) — 16 คอลัมน์
    // คอลัมน์ที่แอปนี้ไม่ได้เก็บ (Data / Secure ID / ReverseBase36 / GPIO) จะเว้นว่าง
    static string ToAscii(string hex)
    {
        try
        {
            hex = hex.Replace(" ", "");
            var s = new StringBuilder();
            for (int k = 0; k + 1 < hex.Length; k += 2)
            {
                int v = Convert.ToInt32(hex.Substring(k, 2), 16);
                s.Append(v >= 32 && v < 127 ? (char)v : '.');
            }
            return s.ToString();
        }
        catch { return ""; }
    }

    var sb = new StringBuilder();
    sb.AppendLine("#, EPC, EPC (ASCII), EPC (ReverseBase36), Data, Data (ASCII), Secure ID, Time Stamp (ms), RSSI (dBm), Read Count, Tag Type, Antenna, Protocol, Frequency (kHz), Phase, GPIO Status");
    int i = 1;
    foreach (var t in reader.Snapshot())
    {
        long ts = new DateTimeOffset(t.LastSeen).ToUnixTimeMilliseconds();
        sb.AppendLine($"{i++}, {t.Epc}, {ToAscii(t.Epc)}, , , , , {ts}, {t.Rssi}, {t.ReadCount}, GEN2, {t.Antenna}, GEN2, {t.Frequency}, {t.Phase}, ");
    }
    return Results.File(Encoding.UTF8.GetBytes(sb.ToString()), "text/csv",
        $"tagResults_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
});

// Export Excel (.xlsx) พร้อมกราฟฝังในไฟล์
app.MapGet("/api/export/xlsx", () =>
{
    var bytes = ExcelReport.Build(reader.Snapshot().ToList());
    return Results.File(bytes,
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        $"rfid_report_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
});

app.Run();

record StartRequest(
    string? Port, string? Region, int? Power, int? Antenna, int? Baud,
    int? RfOn, int? RfOff, string? ReadMode, int? ReadN,
    bool? FilterEnable, string? FilterEpc, string? SearchMode, bool? GpoAuto,
    string? RfMode, string? PowerMode,
    string? PowerScope, List<PortPower>? PortPowers,
    int? WritePower, bool? AntDetect, bool? AntMux, int[]? AntennaList);
record DetectRequest(string? Port, int? Baud);
record AntennaCheckRequest(string? Port, int? Baud, int? Antenna);
record QcRunRequest(string? Port, int? Baud, string? Region, int? Power, int? Antenna, int? N, int? Duration);
record SweepRequest(string? Port, int? Baud, string? Region, int? Antenna, int? Start, int? End, int? Step, int? N);
record TagNameRequest(string Epc, string? Name);
record GpoRequest(int Pin, bool State);
