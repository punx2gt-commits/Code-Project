namespace M7eTagTester;

public class TagInfo
{
    public string Epc { get; set; } = "";
    public string Name { get; set; } = "";   // ชื่อที่ผู้ใช้ตั้งให้ tag นี้
    public int ReadCount { get; set; }
    public int Rssi { get; set; }      // dBm (ค่าลบ ยิ่งใกล้ 0 ยิ่งแรง)
    public int Antenna { get; set; }
    public int Frequency { get; set; }   // kHz
    public int Phase { get; set; }
    public DateTime FirstSeen { get; set; }
    public DateTime LastSeen { get; set; }
}
