using Microsoft.AspNetCore.SignalR;

namespace M7eTagTester;

// Hub ว่างๆ — ฝั่ง server ใช้ IHubContext push ข้อมูลออกไปหา client เอง
public class TagHub : Hub { }
