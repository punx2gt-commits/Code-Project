' หยุดเซิร์ฟเวอร์ RFID Tag Tester (ปิดแบบเงียบ ไม่มีหน้าต่าง)
CreateObject("WScript.Shell").Run "taskkill /IM M7eTagTester.exe /F", 0, True
