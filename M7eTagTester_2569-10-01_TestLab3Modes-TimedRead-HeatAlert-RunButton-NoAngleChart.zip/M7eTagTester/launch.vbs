' ============================================================
'  เปิด M7e-DEKA RFID Tag Tester แบบแอป (ซ่อนหน้าต่างเซิร์ฟเวอร์ เห็นแค่เบราว์เซอร์)
' ============================================================
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir  = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = appDir

' ถ้าเซิร์ฟเวอร์ยังไม่ทำงาน ค่อยเปิด (กันเปิดซ้ำหลายตัว)
Dim already : already = False
On Error Resume Next
Set svc = GetObject("winmgmts:\\.\root\cimv2")
Set procs = svc.ExecQuery("SELECT Name FROM Win32_Process WHERE Name='M7eTagTester.exe'")
If Not procs Is Nothing Then If procs.Count > 0 Then already = True
On Error GoTo 0

If Not already Then
    ' 0 = ซ่อนหน้าต่างเซิร์ฟเวอร์ (ฟีลเหมือนแอป)
    sh.Run """" & appDir & "\M7eTagTester.exe"" --urls http://localhost:5000", 0, False
    WScript.Sleep 3500   ' รอเซิร์ฟเวอร์ขึ้น
End If

' เปิดเบราว์เซอร์ไปหน้าโปรแกรม
sh.Run "http://localhost:5000", 1, False
