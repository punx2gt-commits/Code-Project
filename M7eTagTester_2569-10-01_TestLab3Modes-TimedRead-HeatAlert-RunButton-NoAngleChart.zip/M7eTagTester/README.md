# M7e RFID Tag Tester (Web Dashboard)

เครื่องทดสอบ RFID tag ผ่านเว็บ — อ่าน tag จาก ThingMagic M7e ด้วย MercuryAPI (.NET)
แล้วโชว์ผลแบบ realtime บนหน้าเว็บ (ทดแทน URA เวอร์ชันเขียนเอง)

## โครงสร้าง

```
M7eTagTester/
├── M7eTagTester.csproj   <- โปรเจค ASP.NET Core (.NET 8)
├── Program.cs            <- ตั้ง endpoint + SignalR hub
├── ReaderService.cs      <- หัวใจ: อ่าน tag, dedup, broadcast (มีโหมด sim)
├── TagHub.cs             <- SignalR hub
├── TagInfo.cs            <- model ของ tag 1 ตัว
└── wwwroot/
    └── index.html        <- หน้า dashboard (ตาราง + counter + ปุ่ม)
```

## ต้องมีก่อน

**เครื่องที่ใช้ build (เครื่องของเราเอง):** ต้องลง **.NET 8 SDK**
- โหลด: https://dotnet.microsoft.com/download/dotnet/8.0  (เลือก SDK x64)
- ถ้ามี Visual Studio + workload "ASP.NET and web development" อยู่แล้วก็พอ
- ถ้ารัน `publish.bat` / `start.bat` แล้วไม่มี .NET มันจะเปิดหน้าโหลดให้อัตโนมัติ

**เครื่องปลายทาง (ที่เอาโปรแกรมไปใช้ เช่น PC สายการผลิต):** **ไม่ต้องลง .NET เลย**
- เพราะ `publish.bat` สร้างแบบ self-contained = ฝัง .NET runtime ไว้ในตัวโปรแกรมแล้ว
- แค่ก๊อป `M7eTagTester-dist.zip` ไปแตก แล้วดับเบิลคลิก `start.bat` รันได้เลย ไม่ต้องต่อเน็ต

## รันโหมดจำลอง (ทดสอบเว็บก่อน ยังไม่ต้องมี reader)

```
cd M7eTagTester
dotnet run
```

เปิดเบราว์เซอร์ไปที่ URL ที่ขึ้นใน console (เช่น http://localhost:5xxx)
ในช่อง "Reader URI / COM" ปล่อยเป็น `sim` แล้วกด **เริ่มอ่าน**
จะเห็น tag ปลอม ๆ ทยอยขึ้นมาในตาราง + counter วิ่งขึ้นเรื่อย ๆ

## เปิดโหมด reader จริง

1. หา `MercuryAPI.dll` (ตัว .NET binding) จากโฟลเดอร์ SDK ของ mercuryapi
   เอามาวางในโฟลเดอร์ `libs/`
2. ใน `M7eTagTester.csproj` เปิด (uncomment) สองอย่าง:
   - `<DefineConstants>USE_MERCURY</DefineConstants>`
   - `<ItemGroup>` ที่ reference `MercuryAPI.dll`
3. ใน `ReaderService.cs` แก้ค่า region ให้ตรงโซนไทย (ตอนนี้ตั้ง `NA` ไว้เป็น placeholder)
4. `dotnet run` แล้วในช่อง URI ใส่ `tmr:///COM7` (เปลี่ยนเลข COM ตามที่เจอใน Device Manager)

## ปุ่มต่าง ๆ
- **เริ่มอ่าน / หยุด** — สั่ง reader เริ่ม/หยุดอ่านแบบต่อเนื่อง
- **ล้างค่า** — เคลียร์ tag ที่อ่านมาทั้งหมด เริ่มนับใหม่
- **Export CSV** — โหลดผลเป็น .csv ไว้แนบรายงาน

## ที่ทำได้ดีกว่า URA (ไอเดียทำต่อ)
- counter "X / 100" + progress bar บอกว่าครบยัง
- ไฮไลต์ tag สัญญาณอ่อน (RSSI ต่ำ) = ตรวจ QC ได้
- ขั้นต่อไป: โหลด list EPC ที่คาดไว้ แล้วโชว์ "tag ที่ยังไม่เจอ" โดยตรง
