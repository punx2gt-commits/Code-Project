using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Options;
#if USE_MERCURY
using ThingMagic;
#endif

namespace M7eTagTester;

/// <summary>reader มีปัญหาระหว่างทดสอบ: Kind = heat (ร้อนเกิน/ตัดการทำงาน), comm (ไม่ตอบสนอง), error (อื่น ๆ)</summary>
public class ReaderFaultException : Exception
{
    public string Kind { get; }
    public ReaderFaultException(string kind, string message) : base(message) { Kind = kind; }

    public static string Classify(string? msg)
    {
        var m = (msg ?? "").ToLowerInvariant();
        if (m.Contains("temperature") || m.Contains("thermal") || m.Contains("0x504") || m.Contains("overheat") || m.Contains("too hot"))
            return "heat";
        if (m.Contains("timeout") || m.Contains("timed out") || m.Contains("no response") || m.Contains("not respond") ||
            m.Contains("port") || m.Contains("serial") || m.Contains("crc") || m.Contains("disconnect") || m.Contains("i/o"))
            return "comm";
        return "error";
    }
}

// ค่าตั้งค่าขั้นสูง (ส่งมาจากหน้าเว็บตอนกดเริ่มอ่าน)
public record ReadSettings(
    int RfOn, int RfOff, string ReadMode, int ReadN,
    bool FilterEnable, string? FilterEpc, string? SearchMode, bool GpoAuto,
    string? RfMode, string? PowerMode,
    string? PowerScope, List<PortPower>? PortPowers,
    int? WritePower, bool AntDetect, bool AntMux, int[]? AntennaList)
{
    public static ReadSettings Default => new(1000, 0, "cont", 10, false, null, "dynamic", false, null, "FULL", "global", null, null, true, false, null);
}

public record PortPower(int Port, int Power);                 // Power = dBm
public record ReaderInfo(string Model, int PowerMin, int PowerMax, int[] Ports);

public class ReaderService
{
    private readonly IHubContext<TagHub> _hub;
    private readonly ReaderOptions _def;
    private readonly string _contentRoot;
    private readonly ConcurrentDictionary<string, TagInfo> _tags = new();
    private Timer? _broadcastTimer;
    private bool _running;
    private int _tick;
    private int? _temp;                       // อุณหภูมิ reader (°C) ; null = ไม่รู้
    private int _faultId;                     // เพิ่มทุกครั้งที่ reader มีปัญหา — เว็บใช้เช็กว่ามี fault ใหม่
    private string? _faultKind, _faultMsg;
    private bool _faultSent;                  // กันแจ้งซ้ำระหว่างรอบอ่านเดียวกัน
    private int _tempFail;                    // อ่านอุณหภูมิไม่ได้ติดกันกี่ครั้ง (reader ค้าง)
    private ReadSettings _adv = ReadSettings.Default;

    private Timer? _simTimer;
    private readonly Random _rng = new();
    private List<string>? _simPool;

#if USE_MERCURY
    private Reader? _reader;
#endif

    private readonly ConcurrentDictionary<string, string> _names = new();

    public ReaderService(IHubContext<TagHub> hub, IOptions<ReaderOptions> opts, IWebHostEnvironment env)
    { _hub = hub; _def = opts.Value; _contentRoot = env.ContentRootPath; LoadNames(); }

    private string NamesPath => Path.Combine(_contentRoot, "tag-names.json");

    private void LoadNames()
    {
        try
        {
            if (File.Exists(NamesPath))
            {
                var d = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(NamesPath));
                if (d != null) foreach (var kv in d) _names[kv.Key] = kv.Value;
            }
        }
        catch { }
    }

    private void SaveNames()
    {
        try { File.WriteAllText(NamesPath, JsonSerializer.Serialize(_names, new JsonSerializerOptions { WriteIndented = true })); }
        catch { }
    }

    // ตั้ง/ลบชื่อให้ tag (ผูกกับ EPC) แล้วจำถาวรในไฟล์ tag-names.json
    public void SetName(string epc, string name)
    {
        if (string.IsNullOrWhiteSpace(epc)) return;
        if (string.IsNullOrWhiteSpace(name)) _names.TryRemove(epc, out _);
        else _names[epc] = name.Trim();
        SaveNames();
        Broadcast();
    }

    public ReaderOptions Defaults => _def;

    // ตรวจ reader: ดึงรุ่น / ช่วง power / พอร์ต (universal เหมือน URA — ไม่ hardcode ค่าของ M7e)
    public ReaderInfo Detect(string? uri, int? baud)
    {
        var u = string.IsNullOrWhiteSpace(uri) ? _def.Uri : uri!.Trim();
        if (string.Equals(u, "sim", StringComparison.OrdinalIgnoreCase))
            return new ReaderInfo("Simulator (sim)", 0, 30, new[] { 1 });
#if USE_MERCURY
        Reader? r = null;
        try
        {
            r = Reader.Create(u);
            try { r.ParamSet("/reader/baudRate", baud ?? _def.BaudRate); } catch { }
            try { r.Connect(); }
            catch (Exception ex) when (ex.Message != null &&
                     (ex.Message.IndexOf("Streaming", StringComparison.OrdinalIgnoreCase) >= 0 ||
                      ex.Message.IndexOf("Connect Successful", StringComparison.OrdinalIgnoreCase) >= 0))
            { try { r.StopReading(); } catch { } }

            string model = "?";
            try { model = r.ParamGet("/reader/version/model")?.ToString() ?? "?"; } catch { }

            int pmin = 0, pmax = 30;
            try { pmin = Convert.ToInt32(r.ParamGet("/reader/radio/powerMin")) / 100; } catch { }
            try { pmax = Convert.ToInt32(r.ParamGet("/reader/radio/powerMax")) / 100; } catch { }

            int[] ports;
            try
            {
                var pl = r.ParamGet("/reader/antenna/portList");
                ports = pl is int[] arr && arr.Length > 0 ? arr : new[] { 1 };
            }
            catch { ports = new[] { 1 }; }

            return new ReaderInfo(model, pmin, pmax, ports);
        }
        finally { try { r?.Destroy(); } catch { } }
#else
        return new ReaderInfo("(โหมด sim เท่านั้น)", 0, 30, new[] { 1 });
#endif
    }

    // ตรวจเสา: คืน "พอร์ตทั้งหมดของ reader" (portList — เหมือน URA) + "พอร์ตที่ detect เจอเสา" (connectedPortList)
    public record AntennaCheck(int[] Ports, int[] Connected);

    public AntennaCheck CheckAntennas(string? uri, int? baud, bool antDetect)
    {
        var u = string.IsNullOrWhiteSpace(uri) ? _def.Uri : uri!.Trim();
        if (string.Equals(u, "sim", StringComparison.OrdinalIgnoreCase))
            return new AntennaCheck(new[] { 1, 2 }, new[] { 1 });   // sim
#if USE_MERCURY
        Reader? r = null;
        try
        {
            r = Reader.Create(u);
            try { r.ParamSet("/reader/baudRate", baud ?? _def.BaudRate); } catch { }
            try { r.Connect(); }
            catch (Exception ex) when (ex.Message != null &&
                     (ex.Message.IndexOf("Streaming", StringComparison.OrdinalIgnoreCase) >= 0 ||
                      ex.Message.IndexOf("Connect Successful", StringComparison.OrdinalIgnoreCase) >= 0))
            { try { r.StopReading(); } catch { } }

            // พอร์ตจริงของ reader (เชื่อถือได้ — URA ใช้อันนี้โชว์)
            int[] ports;
            try { var pl = r.ParamGet("/reader/antenna/portList"); ports = pl is int[] a && a.Length > 0 ? a : new[] { 1 }; }
            catch { ports = new[] { 1 }; }

            // detect เสา (best-effort — บาง setup ไม่ผ่านเกณฑ์ return loss)
            int[] connected = Array.Empty<int>();
            try { if (antDetect) r.ParamSet("/reader/antenna/checkPort", true); } catch { }
            try { var cp = r.ParamGet("/reader/antenna/connectedPortList"); connected = cp is int[] c ? c : Array.Empty<int>(); }
            catch { }

            return new AntennaCheck(ports, connected);
        }
        catch { return new AntennaCheck(new[] { 1 }, Array.Empty<int>()); }
        finally { try { r?.Destroy(); } catch { } }
#else
        return new AntennaCheck(new[] { 1 }, new[] { 1 });
#endif
    }

    // ทดสอบ QC: อ่าน N ครั้ง นับว่าเจอกี่ครั้ง (detection) + เก็บ RSSI  → ใช้คำนวณ Wilson ฝั่งเว็บ
    public record QcSample(int T, int R);   // T = ms นับจากเริ่มอ่าน, R = RSSI (0 = รอบนั้นอ่านไม่เจอ)
    public record QcResult(string Epc, int Hits, int N, double RssiAvg, int RssiMin, int RssiMax, double RssiSd = 0,
                           int DurationMs = 0, List<QcSample>? Samples = null);

    static double Sd(List<int> v)
    {
        if (v.Count < 2) return 0;
        double m = v.Average();
        return Math.Sqrt(v.Sum(x => (x - m) * (x - m)) / (v.Count - 1));
    }

    // ทดสอบ QC: อ่าน N ครั้ง หรือ อ่านต่อเนื่องจนครบ durationSec วินาที (เช่น 60 วิ = ตู้หมุน 1 รอบ)
    //   โหมดเวลา: เก็บ timestamp + RSSI ทุกครั้งที่อ่าน → เว็บแปลงเวลาเป็นมุมหมุนได้
    public QcResult QcRun(string? uri, int? baud, string? region, int? powerDbm, int? antenna, int n, int durationSec = 0)
    {
        n = Math.Max(1, n);
        int durMs = Math.Clamp(durationSec, 0, 600) * 1000;
        bool timed = durMs > 0;
        var u = string.IsNullOrWhiteSpace(uri) ? _def.Uri : uri!.Trim();

        QcResult Loop(Func<long, (bool found, int rssi, string? epc, string? err)> attempt)
        {
            int hits = 0, i = 0, consecErr = 0; var rs = new List<int>(); string epc = "";
            var samples = timed ? new List<QcSample>() : null;
            var sw = System.Diagnostics.Stopwatch.StartNew(); long lastLive = -1000;
            while (timed ? sw.ElapsedMilliseconds < durMs : i < n)
            {
                var (f, rssi, e, err) = attempt(sw.ElapsedMilliseconds); i++;
                if (err != null)
                {   // ร้อนเกิน = หยุดทันที ; error อื่นติดกัน 8 ครั้ง = reader ค้าง
                    var k = ReaderFaultException.Classify(err);
                    if (k == "heat" || ++consecErr >= 8) { var fx = new ReaderFaultException(k == "error" ? "comm" : k, err); RecordFault(fx); throw fx; }
                }
                else consecErr = 0;
                if (f) { hits++; rs.Add(rssi); if (epc == "" && e != null) epc = e; }
                long el = sw.ElapsedMilliseconds;
                samples?.Add(new QcSample((int)el, f ? rssi : 0));
                if (!timed) QcLive(i, n, hits, rssi, f);
                else if (el - lastLive >= 200) { QcLiveTimed(i, hits, rssi, f, (int)el, durMs); lastLive = el; }
            }
            if (timed) QcLiveTimed(i, hits, 0, false, durMs, durMs);
            return new QcResult(epc, hits, i, rs.Count > 0 ? rs.Average() : 0, rs.Count > 0 ? rs.Min() : 0,
                                rs.Count > 0 ? rs.Max() : 0, Sd(rs), timed ? durMs : 0, samples);
        }

        if (string.Equals(u, "sim", StringComparison.OrdinalIgnoreCase))
        {
            return Loop(el =>
            {
                // จำลองแท็กบนแท่นหมุน: สัญญาณเปลี่ยนตามมุม มีมุมอับช่วง ~200–240°
                double ang = timed ? (el * 360.0 / durMs) % 360 : 0;
                double dip = timed ? Math.Max(0, Math.Cos((ang - 220) * Math.PI / 180)) : 0;
                bool found = _rng.NextDouble() < 0.98 - 0.45 * Math.Pow(dip, 6);
                int rssi = found ? (int)Math.Round(-47 + 5 * Math.Cos(ang * Math.PI / 180) - 14 * Math.Pow(dip, 3) - _rng.Next(3)) : 0;
                try { System.Threading.Thread.Sleep(timed ? 70 : 35); } catch { }
                return (found, rssi, "E28011700000021D3F0C0371", (string?)null);
            });
        }
#if USE_MERCURY
        Reader? r = null;
        try
        {
            r = Reader.Create(u);
            try { r.ParamSet("/reader/baudRate", baud ?? _def.BaudRate); } catch { }
            try { r.Connect(); }
            catch (Exception ex) when (ex.Message != null &&
                     (ex.Message.IndexOf("Streaming", StringComparison.OrdinalIgnoreCase) >= 0 ||
                      ex.Message.IndexOf("Connect Successful", StringComparison.OrdinalIgnoreCase) >= 0))
            { try { r.StopReading(); } catch { } }

            var reg = string.IsNullOrWhiteSpace(region) ? _def.Region : region!;
            if (!Enum.TryParse<Reader.Region>(reg, true, out var rg)) rg = Reader.Region.OPEN;
            try { r.ParamSet("/reader/region/id", rg); } catch { }
            try { r.ParamSet("/reader/radio/readPower", (powerDbm ?? _def.ReadPowerDbm) * 100); } catch { }
            int ant = antenna ?? _def.Antenna;
            try { r.ParamSet("/reader/read/plan", new SimpleReadPlan(new int[] { ant }, TagProtocol.GEN2, null, 1000)); } catch { }

            var rd = r;
            return Loop(_ =>
            {
                try { foreach (var tr in rd.Read(60)) return (true, tr.Rssi, tr.EpcString, (string?)null); }   // อ่านสั้น ๆ 1 รอบ (แผ่นเดียว)
                catch (Exception ex) { return (false, 0, null, ex.Message); }
                return (false, 0, null, null);
            });
        }
        finally { try { r?.Destroy(); } catch { } }
#else
        return new QcResult("(sim)", 0, n, 0, 0, 0);
#endif
    }

    private void QcLiveTimed(int i, int hits, int rssi, bool found, int el, int dur)
    { try { _hub.Clients.All.SendAsync("qcLive", new { i, n = 0, hits, rssi, found, el, dur }); } catch { } }

    public bool Running => _running;
    public int? Temperature => _temp;          // ให้ /api/status ดึงไปโชว์
    public object FaultInfo => new { id = _faultId, kind = _faultKind, message = _faultMsg };

    // reader แจ้ง error / ตัดการทำงาน → แจ้งเว็บ (popup) แล้วปิดการเชื่อมต่อให้สะอาด เพื่อให้เชื่อมต่อใหม่ได้
    private void RaiseFault(string kind, string message)
    {
        if (_faultSent) return;
        _faultSent = true;
        _faultId++; _faultKind = kind; _faultMsg = message;
        Console.WriteLine($"[ReaderFault] {kind}: {message} (temp={_temp})");
        try { _hub.Clients.All.SendAsync("readerFault", new { id = _faultId, kind, message, temp = _temp }); } catch { }
        System.Threading.Tasks.Task.Run(async () => { await System.Threading.Tasks.Task.Delay(200); try { Stop(); } catch { } });
    }
    private void RecordFault(ReaderFaultException ex)   // ใช้กับโหมดทดสอบ (ไม่มี read ต่อเนื่องให้หยุด)
    {
        _faultId++; _faultKind = ex.Kind; _faultMsg = ex.Message;
        Console.WriteLine($"[ReaderFault] {ex.Kind}: {ex.Message}");
    }

    // รายชื่อ COM port + ชื่ออุปกรณ์ (เหมือน Reader Name ใน URA)
    public record PortInfo(string Port, string Name);

    [System.Runtime.Versioning.SupportedOSPlatform("windows")]
    public List<PortInfo> GetPorts()
    {
        // ดึงชื่ออุปกรณ์ของแต่ละ COM จาก Windows (WMI) เช่น "Silicon Labs CP210x ... (COM7)"
        var friendly = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            using var s = new System.Management.ManagementObjectSearcher(
                "SELECT Caption FROM Win32_PnPEntity WHERE Caption LIKE '%(COM%'");
            foreach (var o in s.Get())
            {
                var cap = o["Caption"]?.ToString() ?? "";
                var m = System.Text.RegularExpressions.Regex.Match(cap, @"\((COM\d+)\)");
                if (m.Success)
                    friendly[m.Groups[1].Value] = cap.Replace($"({m.Groups[1].Value})", "").Trim();
            }
        }
        catch { /* non-Windows หรืออ่าน WMI ไม่ได้ — ใช้ชื่อ default */ }

        var list = new List<PortInfo>();
        try
        {
            foreach (var p in System.IO.Ports.SerialPort.GetPortNames().Distinct().OrderBy(x => x))
                list.Add(new PortInfo(p, friendly.TryGetValue(p, out var n) && n.Length > 0 ? n : "Serial device"));
        }
        catch { }
        return list;
    }

    // ===== ตรวจไดรเวอร์ =====
    public record DriverLink(string Name, string Url);
    public record DriverCheck(int PortCount, List<PortInfo> Ports, bool DeviceNeedsDriver,
                              string? SuspectName, string? Hint, List<DriverLink> Links);

    [System.Runtime.Versioning.SupportedOSPlatform("windows")]
    public DriverCheck CheckDriver()
    {
        var ports = GetPorts();
        bool needs = false; string? suspect = null; string? hint = null;

        try
        {
            // หาอุปกรณ์ที่มีปัญหา (ConfigManagerErrorCode != 0) — error 28 = ไม่มีไดรเวอร์
            using var s = new System.Management.ManagementObjectSearcher(
                "SELECT Name, PNPDeviceID, ConfigManagerErrorCode FROM Win32_PnPEntity WHERE ConfigManagerErrorCode <> 0");
            foreach (var o in s.Get())
            {
                var name = o["Name"]?.ToString() ?? "";
                var id = (o["PNPDeviceID"]?.ToString() ?? "").ToUpperInvariant();
                var err = Convert.ToInt32(o["ConfigManagerErrorCode"] ?? 0);

                // สนใจเฉพาะอุปกรณ์ USB ที่น่าจะเป็น serial/UART หรือไม่มีไดรเวอร์ (err 28)
                bool usbSerialish = id.Contains("USB") &&
                    (err == 28
                     || name.IndexOf("serial", StringComparison.OrdinalIgnoreCase) >= 0
                     || name.IndexOf("uart", StringComparison.OrdinalIgnoreCase) >= 0
                     || name.Length == 0
                     || name.IndexOf("unknown", StringComparison.OrdinalIgnoreCase) >= 0);
                if (!usbSerialish) continue;

                needs = true;
                suspect = string.IsNullOrWhiteSpace(name) ? "อุปกรณ์ USB ที่ไม่รู้จัก" : name;
                if (id.Contains("VID_0403")) hint = "FTDI";
                else if (id.Contains("VID_10C4")) hint = "CP210x";
                else if (id.Contains("VID_067B")) hint = "Prolific";
                break;
            }
        }
        catch { /* อ่าน WMI ไม่ได้ ก็แค่ไม่ระบุอุปกรณ์ */ }

        var links = new List<DriverLink>
        {
            new("FTDI VCP (USB Serial Port)", "https://ftdichip.com/drivers/vcp-drivers/"),
            new("Silicon Labs CP210x", "https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers"),
            new("Prolific PL2303", "https://www.prolific.com.tw/US/ShowProduct.aspx?p_id=225&pcid=41")
        };
        return new DriverCheck(ports.Count, ports, needs, suspect, hint, links);
    }

    public IEnumerable<TagInfo> Snapshot()
    {
        var list = _tags.Values.OrderByDescending(t => t.LastSeen).ToList();
        foreach (var t in list) t.Name = _names.TryGetValue(t.Epc, out var n) ? n : "";
        return list;
    }

    public void SaveDefaults(ReaderOptions o)
    {
        if (!string.IsNullOrWhiteSpace(o.Uri))    _def.Uri = o.Uri.Trim();
        if (!string.IsNullOrWhiteSpace(o.Region)) _def.Region = o.Region.Trim();
        _def.ReadPowerDbm = o.ReadPowerDbm;
        _def.Antenna = o.Antenna;
        if (o.BaudRate > 0) _def.BaudRate = o.BaudRate;
        _def.ExpectedTags = o.ExpectedTags;

        // ค่าขั้นสูง
        if (!string.IsNullOrWhiteSpace(o.ReadMode))   _def.ReadMode = o.ReadMode.Trim();
        _def.ReadN = o.ReadN > 0 ? o.ReadN : _def.ReadN;
        _def.RfOn = Math.Max(0, o.RfOn);
        _def.RfOff = Math.Max(0, o.RfOff);
        if (!string.IsNullOrWhiteSpace(o.SearchMode)) _def.SearchMode = o.SearchMode.Trim();
        _def.FilterEnable = o.FilterEnable;
        _def.FilterEpc = o.FilterEpc ?? "";
        _def.GpoAuto = o.GpoAuto;
        _def.RfMode = o.RfMode ?? "";
        if (!string.IsNullOrWhiteSpace(o.PowerMode)) _def.PowerMode = o.PowerMode.Trim();

        // เขียนลงไฟล์ appsettings.json — ถ้าเขียนไม่ได้ (ไฟล์ถูกเปิดค้าง/permission)
        // ก็ยังใช้ค่าในหน่วยความจำได้ในเซสชันนี้ ไม่ทำให้ปุ่ม "บันทึกค่า" error ทั้งดุ้น
        try
        {
            var path = Path.Combine(_contentRoot, "appsettings.json");
            JsonObject root = File.Exists(path)
                ? (JsonNode.Parse(File.ReadAllText(path))?.AsObject() ?? new JsonObject())
                : new JsonObject();
            root["Reader"] = new JsonObject
            {
                ["Uri"] = _def.Uri,
                ["Region"] = _def.Region,
                ["ReadPowerDbm"] = _def.ReadPowerDbm,
                ["Antenna"] = _def.Antenna,
                ["BaudRate"] = _def.BaudRate,
                ["ExpectedTags"] = _def.ExpectedTags,
                ["WeakRssi"] = _def.WeakRssi,
                ["ReadMode"] = _def.ReadMode,
                ["ReadN"] = _def.ReadN,
                ["RfOn"] = _def.RfOn,
                ["RfOff"] = _def.RfOff,
                ["SearchMode"] = _def.SearchMode,
                ["FilterEnable"] = _def.FilterEnable,
                ["FilterEpc"] = _def.FilterEpc,
                ["GpoAuto"] = _def.GpoAuto,
                ["RfMode"] = _def.RfMode,
                ["PowerMode"] = _def.PowerMode
            };
            File.WriteAllText(path, root.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[SaveDefaults] เขียน appsettings.json ไม่ได้ (ใช้ค่าชั่วคราวในหน่วยความจำแทน): {ex.Message}");
        }
    }

    public void Start(string? uri, string? region, int? powerDbm, int? antenna, int? baud, ReadSettings? adv = null)
    {
        if (_running) return;
        _running = true;
        _adv = adv ?? ReadSettings.Default;

        var u   = string.IsNullOrWhiteSpace(uri)    ? _def.Uri    : uri.Trim();
        var reg = string.IsNullOrWhiteSpace(region) ? _def.Region : region.Trim();
        var pwr = powerDbm ?? _def.ReadPowerDbm;
        var ant = antenna  ?? _def.Antenna;
        var bd  = baud     ?? _def.BaudRate;

        if (string.Equals(u, "sim", StringComparison.OrdinalIgnoreCase))
            StartSimulation();
        else
            StartReader(u, reg, pwr, ant, bd, _adv);

        _tick = 0; _faultSent = false; _tempFail = 0;
        _broadcastTimer = new Timer(_ =>
        {
            if (++_tick % 8 == 0) RefreshTemperature();   // อ่านอุณหภูมิ ~ทุก 2 วิ
            Broadcast();
        }, null, 250, 250);
    }

    public void Stop()
    {
        _running = false;
        _temp = null;
        _broadcastTimer?.Dispose(); _broadcastTimer = null;
        _simTimer?.Dispose(); _simTimer = null;
#if USE_MERCURY
        var r = _reader;
        _reader = null;                       // ตัด reference ก่อน กัน read-task/broadcast แตะต่อ
        if (r != null)
        {
            try { r.StopReading(); } catch { }                       // หยุด async read (แยก try)
            try { System.Threading.Thread.Sleep(150); } catch { }    // รอ callback + read loop จบ
            try { r.Destroy(); } catch { }                           // ปิด connection/พอร์ต — ต้องรันเสมอ
        }
#endif
        Broadcast();
    }

    public void Reset() { _tags.Clear(); Broadcast(); }

    // สั่ง GPO (รีเลย์/ไฟ) — เรียกจาก /api/gpo และจาก QC อัตโนมัติฝั่งเว็บ
    // หมายเหตุ: GPO ของ M7e ค่า default = HIGH และจะดีดกลับ HIGH เมื่อหยุดอ่าน (กรณีเปิด antenna multiplexing)
    //          DEKA ไม่สลับ GPIO1/2 เหมือน MEGA/TERA
    public void SetGpo(int pin, bool state)
    {
#if USE_MERCURY
        if (_reader == null) throw new InvalidOperationException("ยังไม่ได้เชื่อมต่อ reader");
        _reader.GpoSet(new[] { new GpioPin(pin, state) });   // ⚠️ เช็ก constructor GpioPin ตามเวอร์ชัน DLL
#else
        // โหมด sim: ไม่ทำอะไร (ปล่อยผ่าน)
#endif
    }

    private void RefreshTemperature()
    {
        if (!_running) return;
#if USE_MERCURY
        if (_reader != null)
        {
            try { _temp = Convert.ToInt32(_reader.ParamGet("/reader/radio/temperature")); _tempFail = 0; }
            catch (Exception ex)
            {
                // เคยอ่านได้ แต่ตอนนี้อ่านไม่ได้ติดกัน 3 ครั้ง (~6 วิ) = reader ไม่ตอบสนอง
                if (_temp != null && ++_tempFail >= 3)
                {
                    var k = ReaderFaultException.Classify(ex.Message);
                    RaiseFault(k == "error" ? "comm" : k, ex.Message);
                }
            }
            return;
        }
#endif
        if (_simTimer != null) _temp = 36 + _rng.Next(0, 5);   // ค่าจำลองให้ chip โชว์ในโหมด sim
    }

    private void Record(string epc, int rssi, int antenna, int freq = 0, int phase = 0)
    {
        _tags.AddOrUpdate(epc,
            _ => new TagInfo { Epc = epc, ReadCount = 1, Rssi = rssi, Antenna = antenna, Frequency = freq, Phase = phase,
                               FirstSeen = DateTime.Now, LastSeen = DateTime.Now },
            (_, t) => { t.ReadCount++; t.Rssi = rssi; t.Antenna = antenna; if (freq > 0) t.Frequency = freq; t.Phase = phase; t.LastSeen = DateTime.Now; return t; });
    }

    // ===== Power Sweep (P50): ไล่ power ต่ำ→สูง อ่าน N ครั้งต่อสเต็ป — ต่อ reader ครั้งเดียวทั้งชุด =====
    public record SweepPoint(int Power, int Hits, int N, double RssiAvg);

    public List<SweepPoint> SweepRun(string? uri, int? baud, string? region, int? antenna,
                                     int pStart, int pEnd, int pStep, int n)
    {
        n = Math.Max(1, n); pStep = Math.Max(1, Math.Abs(pStep));
        if (pEnd < pStart) (pStart, pEnd) = (pEnd, pStart);
        var steps = new List<int>();
        for (int p = pStart; p <= pEnd; p += pStep) steps.Add(p);
        var outp = new List<SweepPoint>();
        var u = string.IsNullOrWhiteSpace(uri) ? _def.Uri : uri!.Trim();

        if (string.Equals(u, "sim", StringComparison.OrdinalIgnoreCase))
        {
            double turnOn = 12 + _rng.Next(6);                 // จำลองแท็กเริ่มตอบราว 12–17 dBm
            for (int k = 0; k < steps.Count; k++)
            {
                int p = steps[k]; int h = 0; var rs = new List<int>();
                double prob = 1 / (1 + Math.Exp(-(p - turnOn) * 1.1));
                for (int i = 0; i < n; i++) if (_rng.NextDouble() < prob) { h++; rs.Add(-80 + (p - 5) - _rng.Next(4)); }
                outp.Add(new SweepPoint(p, h, n, rs.Count > 0 ? rs.Average() : 0));
                SweepLive(k + 1, steps.Count, p, h, n);
                try { System.Threading.Thread.Sleep(90); } catch { }
            }
            return outp;
        }
#if USE_MERCURY
        Reader? r = null;
        try
        {
            r = Reader.Create(u);
            try { r.ParamSet("/reader/baudRate", baud ?? _def.BaudRate); } catch { }
            try { r.Connect(); }
            catch (Exception ex) when (ex.Message != null &&
                     (ex.Message.IndexOf("Streaming", StringComparison.OrdinalIgnoreCase) >= 0 ||
                      ex.Message.IndexOf("Connect Successful", StringComparison.OrdinalIgnoreCase) >= 0))
            { try { r.StopReading(); } catch { } }

            var reg = string.IsNullOrWhiteSpace(region) ? _def.Region : region!;
            if (!Enum.TryParse<Reader.Region>(reg, true, out var rg)) rg = Reader.Region.OPEN;
            try { r.ParamSet("/reader/region/id", rg); } catch { }
            int ant = antenna ?? _def.Antenna;
            try { r.ParamSet("/reader/read/plan", new SimpleReadPlan(new int[] { ant }, TagProtocol.GEN2, null, 1000)); } catch { }

            int minC = 0, maxC = 3000;   // clamp ตามเพดานของ reader จริง (universal)
            try { minC = Convert.ToInt32(r.ParamGet("/reader/radio/powerMin")); } catch { }
            try { maxC = Convert.ToInt32(r.ParamGet("/reader/radio/powerMax")); } catch { }

            for (int k = 0; k < steps.Count; k++)
            {
                int p = steps[k];
                int centi = Math.Clamp(p * 100, minC, maxC);
                try { r.ParamSet("/reader/radio/readPower", centi); } catch { }
                try { System.Threading.Thread.Sleep(30); } catch { }
                int h = 0, consecErr = 0; var rs = new List<int>();
                for (int i = 0; i < n; i++)
                {
                    try { foreach (var tr in r.Read(60)) { h++; rs.Add(tr.Rssi); break; } consecErr = 0; }
                    catch (Exception ex)
                    {
                        var kk = ReaderFaultException.Classify(ex.Message);
                        if (kk == "heat" || ++consecErr >= 8) { var fx = new ReaderFaultException(kk == "error" ? "comm" : kk, ex.Message); RecordFault(fx); throw fx; }
                    }
                }
                outp.Add(new SweepPoint(centi / 100, h, n, rs.Count > 0 ? rs.Average() : 0));
                SweepLive(k + 1, steps.Count, centi / 100, h, n);
            }
            return outp;
        }
        finally { try { r?.Destroy(); } catch { } }
#else
        return outp;
#endif
    }

    private void SweepLive(int k, int total, int power, int hits, int n)
    { try { _hub.Clients.All.SendAsync("sweepLive", new { k, total, power, hits, n }); } catch { } }

    private void Broadcast() => _hub.Clients.All.SendAsync("update", Snapshot());
    private void QcLive(int i, int n, int hits, int rssi, bool found)
    { try { _hub.Clients.All.SendAsync("qcLive", new { i, n, hits, rssi, found }); } catch { } }

    private void StartSimulation()
    {
        _simPool ??= Enumerable.Range(1, 100)
            .Select(i => $"E2000017221101441890{i:D4}")
            .ToList();
        _temp = 38;
        _simTimer = new Timer(_ =>
        {
            var epc = _simPool![_rng.Next(_simPool.Count)];
            Record(epc, -30 - _rng.Next(45), 1, 920000 + _rng.Next(6) * 1000, _rng.Next(180));
        }, null, 0, 60);
    }

    private void StartReader(string uri, string region, int powerDbm, int antenna, int baud, ReadSettings adv)
    {
#if USE_MERCURY
        // กัน reader ตัวเก่าค้าง (เผื่อ Stop ก่อนหน้าปิดไม่สนิท) — ปิดให้แน่ก่อนสร้างใหม่
        if (_reader != null)
        {
            var old = _reader; _reader = null;
            try { old.StopReading(); } catch { }
            try { old.Destroy(); } catch { }
        }
        _reader = Reader.Create(uri);

        // ตั้ง baud ก่อนเชื่อมต่อ (best-effort — ถ้า reader auto-baud อยู่แล้วก็ข้ามได้)
        try { _reader.ParamSet("/reader/baudRate", baud); } catch { }

        // เชื่อมต่อ — ถ้าโมดูลกำลัง stream tags ค้างอยู่ (autonomous read) Connect จะโยนข้อความ
        // "Connect Successful...Streaming tags" ซึ่งจริง ๆ แปลว่า "ต่อติดแล้ว แต่กำลังสตรีม"
        // → จับไว้ แล้วสั่งหยุดสตรีมเดิม จากนั้นค่อยตั้งค่าของเราเอง
        try
        {
            _reader.Connect();
        }
        catch (Exception ex) when (ex.Message != null &&
                 (ex.Message.IndexOf("Streaming", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  ex.Message.IndexOf("Connect Successful", StringComparison.OrdinalIgnoreCase) >= 0))
        {
            try { _reader.StopReading(); } catch { }
            System.Threading.Thread.Sleep(150);
        }

        // โซนความถี่ — M7e รองรับ TH โดยตรง ใช้ default hop table ของโซนนั้น
        // (อย่าตั้ง minFrequency เองสำหรับ TH/AU/NZ ฯลฯ เพราะ GetMinFrequency มีบั๊กคืน 902750)
        if (!Enum.TryParse<Reader.Region>(region, true, out var reg))
            reg = Reader.Region.OPEN;
        _reader.ParamSet("/reader/region/id", reg);

        // อ่านเพดาน power ของ reader (universal — ไม่ hardcode) แล้ว clamp ไม่ให้เกิน
        int maxCenti = 3000;
        try { maxCenti = Convert.ToInt32(_reader.ParamGet("/reader/radio/powerMax")); } catch { }

        if (string.Equals(adv.PowerScope, "perport", StringComparison.OrdinalIgnoreCase)
            && adv.PortPowers != null && adv.PortPowers.Count > 0)
        {
            // Per Port — ตั้ง power แยกแต่ละพอร์ต
            // ⚠️ เช็ก type ของ portReadPowerList ตามเวอร์ชัน DLL (ปกติ int[][] : {port, centi-dBm})
            var list = adv.PortPowers
                .Select(pp => new int[] { pp.Port, Math.Min(pp.Power * 100, maxCenti) })
                .ToArray();
            try { _reader.ParamSet("/reader/radio/portReadPowerList", list); }
            catch { /* reader บางรุ่นไม่รองรับ per-port ก็ข้าม */ }
        }
        else
        {
            // Global
            _reader.ParamSet("/reader/radio/readPower", Math.Min(powerDbm * 100, maxCenti));
        }

        // Write Power (ถ้าระบุ)
        if (adv.WritePower.HasValue)
        {
            try { _reader.ParamSet("/reader/radio/writePower", Math.Min(adv.WritePower.Value * 100, maxCenti)); }
            catch { }
        }

        // Antenna Detection — เปิด/ปิดการตรวจเสาอัตโนมัติ (มีผลกับ connectedPortList)
        try { _reader.ParamSet("/reader/antenna/checkPort", adv.AntDetect); } catch { }
        // Antenna Multiplexing = ใช้เมื่อมี antenna mux/หลายพอร์ต (ค่านี้ pass-through)

        // Power Mode (FULL/MINSAVE/SLEEP) — MINSAVE ช่วยลดความร้อนสำหรับงาน duty สูง
        if (!string.IsNullOrWhiteSpace(adv.PowerMode))
        {
            try
            {
                var pm = Enum.Parse(typeof(Reader.PowerMode), adv.PowerMode!, true);
                _reader.ParamSet("/reader/powerMode", pm);
            }
            catch { /* ชื่อโหมดไม่ตรง enum ก็ข้าม */ }
        }

        // RF Mode — บน M7e ต้องตั้ง BLF/TARI/tagEncoding ผ่าน RF Mode (ตั้งตรง ๆ ไม่ได้)
        // DEKA รองรับ: RFMODE_320_M2_15 / 320_M2_20 / 320_M4_20 / 250_M4_20 / 160_M8_20
        // ใช้ reflection หา enum RF Mode เอง (กันชื่อ type/สมาชิกต่างกันในแต่ละเวอร์ชัน DLL)
        if (!string.IsNullOrWhiteSpace(adv.RfMode))
        {
            try
            {
                Type? rfType = null;
                foreach (var t in typeof(Reader).Assembly.GetTypes())
                    if (t.IsEnum && t.Name.Replace("_", "").IndexOf("rfmode", StringComparison.OrdinalIgnoreCase) >= 0)
                    { rfType = t; break; }

                if (rfType == null)
                    Console.WriteLine("[RFMode] หา enum RF Mode ใน MercuryAPI ไม่เจอ — ข้ามการตั้งค่า");
                else
                {
                    // normalize ชื่อให้เทียบกันได้ เช่น "RFMODE_320_M2_20" -> "32 0M220" (ตัด RFMODE/TMR/GEN2 และ _)
                    static string Norm(string s) => s.ToUpperInvariant()
                        .Replace("RFMODE", "").Replace("TMR", "").Replace("GEN2", "").Replace("_", "").Trim();
                    var want = Norm(adv.RfMode!);
                    object? val = null;
                    foreach (var name in Enum.GetNames(rfType))
                        if (Norm(name) == want) { val = Enum.Parse(rfType, name); break; }

                    if (val != null)
                        _reader.ParamSet("/reader/gen2/rfMode", val);
                    else
                        Console.WriteLine($"[RFMode] ไม่พบโหมดตรงกับ '{adv.RfMode}'. enum={rfType.FullName} ที่มี: {string.Join(", ", Enum.GetNames(rfType))}");
                }
            }
            catch (Exception ex) { Console.WriteLine($"[RFMode] ตั้งไม่ได้: {ex.Message}"); }
        }

        // ตัวกรอง EPC (Gen2 Select) — อ่านเฉพาะแท็กที่ EPC ขึ้นต้นตรง mask
        // (เป็น select filter ปกติ ไม่ใช่ EPC truncation ที่ถูก disable บน M7e)
        TagFilter? filter = null;
        if (adv.FilterEnable && !string.IsNullOrWhiteSpace(adv.FilterEpc))
        {
            var epc = HexToBytes(adv.FilterEpc!.Trim());
            // bitPointer = 32 (ข้าม CRC16 + PC word) ให้ตรงกับ EPC จากต้น
            filter = new Gen2.Select(false, Gen2.Bank.EPC, 32, (ushort)(epc.Length * 8), epc);
            // ⚠️ เช็ก constructor ของ Gen2.Select ตามเวอร์ชัน DLL
        }

        var ants = (adv.AntennaList != null && adv.AntennaList.Length > 0) ? adv.AntennaList : new int[] { antenna };
        var plan = new SimpleReadPlan(ants, TagProtocol.GEN2, filter, 1000);
        _reader.ParamSet("/reader/read/plan", plan);

        // duty cycle (มีผลกับการอ่านต่อเนื่อง)
        try { _reader.ParamSet("/reader/read/asyncOnTime",  Math.Max(0, adv.RfOn)); }  catch { }
        try { _reader.ParamSet("/reader/read/asyncOffTime", Math.Max(0, adv.RfOff)); } catch { }

        _reader.TagRead += (s, e) =>
        {
            var tr = e.TagReadData;
            Record(tr.EpcString, tr.Rssi, tr.Antenna, tr.Frequency, tr.Phase);
        };
        // error ระหว่างอ่านต่อเนื่อง (เช่น ร้อนเกินจนโมดูลตัด RF) → แจ้งเว็บ + ปิดการเชื่อมต่อ
        _reader.ReadException += (s, e) =>
        {
            var msg = e.ReaderException?.Message ?? "ReadException";
            RaiseFault(ReaderFaultException.Classify(msg), msg);
        };

        var mode = (adv.ReadMode ?? "cont").ToLowerInvariant();
        if (mode == "cont")
        {
            _reader.StartReading();                                  // อ่านต่อเนื่อง (async) — แนะนำสำหรับแท็กเยอะ
        }
        else
        {
            // ครั้งเดียว / N แท็ก = sync read (รันใน background ไม่ให้บล็อก request)
            // หมายเหตุ: M7e buffer ของ timed/sync read จำกัด ~48 ตัว/รอบ — แท็กเยอะให้ใช้โหมดต่อเนื่อง
            int want = mode == "n" ? Math.Max(1, adv.ReadN) : 1;
            var rr = _reader;   // อ้างตัวเดิม กัน null ระหว่างทาง
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var deadline = DateTime.Now.AddSeconds(mode == "n" ? 10 : 2);
                    do
                    {
                        if (!_running) break;                        // ถูกสั่งหยุด → ออกทันที
                        foreach (var tr in rr!.Read(300))            // อ่านเป็นก้อนสั้น ๆ ลด race ตอน Destroy
                            Record(tr.EpcString, tr.Rssi, tr.Antenna, tr.Frequency, tr.Phase);
                    }
                    while (mode == "n" && _running && _tags.Count < want && DateTime.Now < deadline);
                }
                catch { }
            });
        }
#else
        throw new InvalidOperationException(
            "ยังไม่ได้เปิดโหมด reader จริง — add reference MercuryAPI.dll แล้ว define USE_MERCURY ใน .csproj ก่อน " +
            "(ระหว่างนี้ใช้โหมดจำลอง sim ได้)");
#endif
    }

    // แปลงสตริง hex (เช่น "E20000172211...") เป็น byte[] สำหรับตัวกรอง EPC
    private static byte[] HexToBytes(string hex)
    {
        hex = hex.Replace(" ", "").Replace("-", "");
        if (hex.Length % 2 != 0) hex = "0" + hex;
        var b = new byte[hex.Length / 2];
        for (int i = 0; i < b.Length; i++)
            b[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
        return b;
    }
}
