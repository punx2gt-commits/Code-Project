libs\ — ไฟล์ MercuryAPI .NET + dependency
==========================================

** ตอนนี้ตั้งค่าให้หมดแล้ว พร้อม build/publish ได้เลย **

ไฟล์ในโฟลเดอร์นี้ (ใส่ครบแล้ว):
  - MercuryAPI.dll        (ตัวหลัก)
  - LLRP.dll              (dependency)
  - log4net.dll           (dependency)
  - Interop.Bonjour.dll   (dependency)
  - AeiTag.dll            (dependency)

สถานะการตั้งค่า:
  - M7eTagTester.csproj เปิด <DefineConstants>USE_MERCURY</DefineConstants> แล้ว
  - เปิด block <Reference Include="MercuryAPI"> แล้ว
  - ตอน build/publish จะลาก .dll ทุกตัวในนี้ไปไว้ข้างๆ exe ให้อัตโนมัติ

เหลือแค่:
  - รัน publish.bat -> ได้ M7eTagTester-dist.zip เอาไปเครื่องอื่นได้เลย
  - เครื่องปลายทางต้องลง driver USB-serial ของ M7e (CP210x / FTDI ฯลฯ) แยกต่างหาก
    (เป็น driver ของ Windows มัดรวมไปกับโปรแกรมไม่ได้)
