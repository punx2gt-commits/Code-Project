using OfficeOpenXml;
using OfficeOpenXml.Drawing.Chart;
using OfficeOpenXml.Style;
using System.Drawing;

namespace M7eTagTester;

// สร้างไฟล์ Excel (.xlsx) ที่มีตารางผลทดสอบ + กราฟเส้นฝังในชีตเลย
public static class ExcelReport
{
    public static byte[] Build(IReadOnlyList<TagInfo> tags)
    {
        // EPPlus 7.x: งานการศึกษา/ไม่เชิงพาณิชย์ ใช้ NonCommercial
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        // เรียงตามตัวที่อ่านเจอก่อน (FirstSeen) → #1, #2, #3…
        var rows = tags.OrderBy(t => t.FirstSeen).ToList();

        using var pkg = new ExcelPackage();
        var ws = pkg.Workbook.Worksheets.Add("ผลทดสอบ Tag");

        string[] headers = { "ลำดับ", "ชื่อ", "EPC", "อ่าน (ครั้ง)", "RSSI (dBm)", "Antenna", "เจอครั้งแรก", "เจอล่าสุด", "Label" };
        for (int c = 0; c < headers.Length; c++) ws.Cells[1, c + 1].Value = headers[c];
        using (var h = ws.Cells[1, 1, 1, headers.Length])
        {
            h.Style.Font.Bold = true;
            h.Style.Font.Color.SetColor(Color.White);
            h.Style.Fill.PatternType = ExcelFillStyle.Solid;
            h.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(11, 31, 74)); // navy RMUTT
            h.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        }

        for (int i = 0; i < rows.Count; i++)
        {
            var t = rows[i];
            int r = i + 2;
            ws.Cells[r, 1].Value = i + 1;            // ลำดับการอ่านเจอ
            ws.Cells[r, 2].Value = t.Name;
            ws.Cells[r, 3].Value = t.Epc;
            ws.Cells[r, 4].Value = t.ReadCount;
            ws.Cells[r, 5].Value = t.Rssi;
            ws.Cells[r, 6].Value = t.Antenna;
            ws.Cells[r, 7].Value = t.FirstSeen;
            ws.Cells[r, 8].Value = t.LastSeen;
            ws.Cells[r, 9].Value = "#" + (i + 1);   // label แกน X ของกราฟ
            ws.Cells[r, 7].Style.Numberformat.Format = "yyyy-mm-dd hh:mm:ss";
            ws.Cells[r, 8].Style.Numberformat.Format = "yyyy-mm-dd hh:mm:ss";

            if (t.Rssi < -65) // ไฮไลต์แถวสัญญาณอ่อน
            {
                using var rowCells = ws.Cells[r, 1, r, 9];
                rowCells.Style.Fill.PatternType = ExcelFillStyle.Solid;
                rowCells.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(255, 228, 228));
            }
        }

        int last = rows.Count + 1; // แถวข้อมูลสุดท้าย (รวม header แถว 1)

        try { ws.Cells[ws.Dimension.Address].AutoFitColumns(); } catch { }
        ws.Column(3).Width = 28; // EPC

        // กล่องสรุป (ขวาของตาราง)
        int avg = rows.Count > 0 ? (int)Math.Round(rows.Average(t => t.Rssi)) : 0;
        ws.Cells[1, 11].Value = "สรุปผล";
        ws.Cells[2, 11].Value = "จำนวน Tag";          ws.Cells[2, 12].Value = rows.Count;
        ws.Cells[3, 11].Value = "อ่านรวม (ครั้ง)";     ws.Cells[3, 12].Value = rows.Sum(t => t.ReadCount);
        ws.Cells[4, 11].Value = "RSSI เฉลี่ย (dBm)";   ws.Cells[4, 12].Value = avg;
        ws.Cells[5, 11].Value = "สัญญาณอ่อน (<-65)";  ws.Cells[5, 12].Value = rows.Count(t => t.Rssi < -65);
        ws.Cells[1, 11, 5, 11].Style.Font.Bold = true;

        // กราฟเส้น (ต้องมีข้อมูลอย่างน้อย 1 แถว)
        if (last >= 2)
        {
            var c1 = ws.Drawings.AddChart("chartRssi", eChartType.LineMarkers);
            c1.Title.Text = "RSSI ของแต่ละ Tag (dBm)";
            c1.SetPosition(last + 2, 5, 0, 0);
            c1.SetSize(760, 360);
            var s1 = c1.Series.Add(ws.Cells[2, 5, last, 5], ws.Cells[2, 9, last, 9]);
            s1.Header = "RSSI (dBm)";

            var c2 = ws.Drawings.AddChart("chartReads", eChartType.LineMarkers);
            c2.Title.Text = "จำนวนครั้งที่อ่าน ต่อ Tag";
            c2.SetPosition(last + 22, 5, 0, 0);
            c2.SetSize(760, 360);
            var s2 = c2.Series.Add(ws.Cells[2, 4, last, 4], ws.Cells[2, 9, last, 9]);
            s2.Header = "อ่าน (ครั้ง)";
        }

        return pkg.GetAsByteArray();
    }
}
