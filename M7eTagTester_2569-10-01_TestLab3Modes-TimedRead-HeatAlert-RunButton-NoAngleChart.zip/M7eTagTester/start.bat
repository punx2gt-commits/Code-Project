@echo off
title RFID Tag Tester
cd /d "%~dp0"

REM เปิดเบราว์เซอร์อัตโนมัติ 5 วิ หลังเซิร์ฟเวอร์เริ่ม
start "" cmd /c "timeout /t 5 >nul & start http://localhost:5000"

REM ถ้ามี .exe (publish แบบ self-contained) -> รันได้เลย ไม่ต้องมี .NET
if exist "M7eTagTester.exe" (
    "M7eTagTester.exe" --urls http://localhost:5000
    exit
)

REM ไม่มี .exe = โหมด dev ต้องใช้ .NET SDK
where dotnet >nul 2>nul
if errorlevel 1 (
    echo ============================================================
    echo  ไม่พบ .NET บนเครื่องนี้
    echo   - จะรันโหมด dev ต้องลง ".NET 8 SDK" ก่อน
    echo   - หรือใช้เวอร์ชันที่ publish แล้ว (มี M7eTagTester.exe ในตัว ไม่ต้องลง .NET)
    echo  กำลังเปิดหน้าดาวน์โหลด .NET...
    echo ============================================================
    start "" https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit
)
dotnet run --urls http://localhost:5000
exit
