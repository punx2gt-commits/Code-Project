@echo off
title Publish M7e-DEKA RFID Tag Tester
cd /d "%~dp0"

REM --- ต้องมี .NET 8 SDK เพื่อ build (เครื่องปลายทางไม่ต้องมี เพราะ publish แบบ self-contained) ---
where dotnet >nul 2>nul
if errorlevel 1 (
    echo ============================================================
    echo  ไม่พบ .NET SDK บนเครื่องนี้
    echo  ต้องลง ".NET 8 SDK" ก่อน จึงจะ build/publish ได้
    echo  กำลังเปิดหน้าดาวน์โหลด...
    echo ============================================================
    start "" https://dotnet.microsoft.com/download/dotnet/8.0
    echo.
    echo *** ลง .NET 8 SDK เสร็จแล้ว ปิดหน้าต่างนี้แล้วรัน publish.bat ใหม่ ***
    pause
    exit /b 1
)

echo ==================================================
echo  Building self-contained (win-x64)...
echo  Target PC needs NO .NET install and NO internet.
echo ==================================================
echo.

dotnet publish -c Release -r win-x64 --self-contained true -o publish
if errorlevel 1 (
    echo.
    echo *** BUILD FAILED - check errors above ***
    pause
    exit /b 1
)

copy /Y start.bat publish\start.bat >nul

echo.
echo Creating distribution zip...
powershell -NoProfile -Command "Compress-Archive -Path 'publish\*' -DestinationPath 'M7eTagTester-dist.zip' -Force"

echo.
echo ============== DONE ==============
echo   publish\               = ready-to-run folder (มี .NET ในตัว ไม่ต้องลงอะไร)
echo   M7eTagTester-dist.zip  = ก๊อปไฟล์เดียวนี้ไปเครื่องอื่นได้เลย
echo.
echo On the target PC: unzip, then double-click start.bat (ไม่ต้องลง .NET)
echo =================================
pause
