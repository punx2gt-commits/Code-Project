; ============================================================
;  Inno Setup Script — RFID Tag Tester
;  ทำเป็น setup.exe ก้อนเดียว ลงทุกอย่างให้ครบในคลิกเดียว
; ============================================================
;  วิธีใช้:
;   1) โหลด Inno Setup (ฟรี): https://jrsoftware.org/isdl.php  แล้วติดตั้ง
;   2) รัน publish.bat ก่อน ให้ได้โฟลเดอร์ publish\
;   3) เปิดไฟล์นี้ (setup.iss) ด้วย Inno Setup → กด Build/Compile (F9)
;   4) ได้ไฟล์  Output\RFIDTagTester-setup.exe  ← เอาไฟล์เดียวนี้ไปแจก
; ============================================================

; อยากเปลี่ยนชื่อโปรแกรม แก้บรรทัดเดียวข้างล่างนี้พอ
#define MyAppName "RFID Tag Tester"
#define MyAppVersion "1.0"
#define MyAppLauncher "start.bat"

[Setup]
AppName={#MyAppName}
AppVersion={#MyAppVersion}
PrivilegesRequired=lowest
DefaultDirName={localappdata}\Programs\RFIDTagTester
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=RFIDTagTester-setup
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern
; ไอคอนของตัว setup.exe = โลโก้ภาค ETE
SetupIconFile=app.ico

[Languages]
Name: "default"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "สร้างไอคอนบนเดสก์ท็อป"; GroupDescription: "เพิ่มเติม:"

[Files]
; โปรแกรม + .NET runtime + MercuryAPI ทั้งหมดจากโฟลเดอร์ publish
Source: "publish\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
; ไอคอนภาค (ให้ shortcut ใช้)
Source: "app.ico"; DestDir: "{app}"; Flags: ignoreversion

; ==== ถ้าจะรวม driver USB-serial ของ M7e ให้มาในตัว ====
; วาง installer ของ driver ไว้ในโฟลเดอร์ drivers\ แล้วเปิดบรรทัดล่าง
; Source: "drivers\CP210xVCPInstaller_x64.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppLauncher}"; WorkingDir: "{app}"; IconFilename: "{app}\app.ico"
Name: "{autodesktop}\{#MyAppName}";  Filename: "{app}\{#MyAppLauncher}"; WorkingDir: "{app}"; IconFilename: "{app}\app.ico"; Tasks: desktopicon

[Run]
; ==== ติดตั้ง driver ตอนจบ (เปิดเมื่อใส่ไฟล์ driver ในโฟลเดอร์ drivers\ แล้ว) ====
; Filename: "{tmp}\CP210xVCPInstaller_x64.exe"; Parameters: "/Q"; StatusMsg: "กำลังติดตั้ง driver USB-serial..."; Flags: waituntilterminated

; เปิดโปรแกรมเลยหลังติดตั้งเสร็จ
Filename: "{app}\{#MyAppLauncher}"; Description: "เปิดโปรแกรมเลย"; Flags: postinstall shellexec skipifsilent
